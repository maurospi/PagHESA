/**
 * ============================================================================
 * ACCESSIBILITY KIT - Universal Web Accessibility Component
 * ============================================================================
 * Version: 1.0.0 (Premium Enterprise)
 * License: MIT
 * Author: Professional Accessibility Team
 * 
 * A comprehensive, WCAG 2.2 AAA compliant accessibility toolkit for any website.
 * Zero dependencies. Pure HTML5, CSS3, JavaScript ES6+.
 * ============================================================================
 */

(function(window) {
    'use strict';

    class AccessibilityKit {
        constructor(options = {}) {
            // Configuration with defaults
            this.config = {
                position: options.position || 'bottom-right',
                primaryColor: options.primaryColor || 'auto',
                secondaryColor: options.secondaryColor || 'auto',
                borderRadius: options.borderRadius || '16px',
                panelWidth: options.panelWidth || '400px',
                language: options.language || 'es',
                theme: options.theme || 'auto',
                savePreferences: options.savePreferences !== false,
                ...options
            };

            // State loaded or defaulted
            this.state = {
                isOpen: false,
                textScale: 100,
                contrast: 'normal',
                grayscale: false,
                invertColors: false,
                highlightLinks: false,
                highlightHeadings: false,
                dyslexiaFont: false,
                letterSpacing: 0, // In px (0, 2, 4, 6)
                wordSpacing: 0,   // In px (0, 4, 8, 12)
                lineHeight: 1.5,  // multiplier (1.5, 1.8, 2.1, 2.4)
                cursorSize: 'normal', // normal, large, extra-large
                readingGuide: false,
                readingMask: false,
                pauseAnimations: false,
                focusVisibility: true,
                hideImages: false,
                readingMode: false,
                currentLanguage: this.config.language,
                favorites: [], // list of actions
                clickCounts: {} // action -> count
            };

            this.elements = {
                container: null,
                button: null,
                panel: null,
                overlay: null,
                readingGuide: null,
                readingMask: null,
                toast: null
            };

            // Speech Synthesis
            this.speechState = {
                isReading: false,
                isPaused: false,
                utterance: null
            };

            this.init();
        }

        init() {
            if (this.config.savePreferences) {
                this.loadPreferences();
            }

            // Detect and adapt colors to branding automatically if configured
            this.adaptBranding();

            // Create structure
            this.createDOM();

            // Setup listeners
            this.setupEventListeners();

            // Apply loaded settings
            this.applySavedSettings();

            // Setup keyboard shortcuts
            this.setupKeyboardShortcuts();

            // Focus management
            this.initializeFocusManagement();

            // Mutation observer for dynamic elements
            this.setupMutationObserver();
            
            // Show brief load toast
            this.showToast(this.t('options.loaded') || 'Kit de accesibilidad listo');
        }

        adaptBranding() {
            // Find branding colors automatically if color is set to 'auto'
            if (this.config.primaryColor === 'auto') {
                // Look for common brand colors
                let color = '#345c5c'; // fallback
                const brandLink = document.querySelector('a, h2 span, .navbar-brand');
                if (brandLink) {
                    const compColor = window.getComputedStyle(brandLink).color;
                    if (compColor && compColor !== 'rgba(0, 0, 0, 0)' && compColor !== 'rgb(0, 0, 0)') {
                        color = compColor;
                    }
                }
                this.config.primaryColor = color;
            }
            if (this.config.secondaryColor === 'auto') {
                this.config.secondaryColor = this.config.primaryColor;
            }
        }

        createDOM() {
            // Container
            const container = document.createElement('div');
            container.id = 'accessibility-kit-container';
            container.setAttribute('data-position', this.config.position);
            container.setAttribute('lang', this.state.currentLanguage);

            // Inject Custom styling CSS properties dynamically based on configuration
            container.style.setProperty('--ak-primary', this.config.primaryColor);
            container.style.setProperty('--ak-secondary', this.config.secondaryColor);
            container.style.setProperty('--ak-radius-lg', this.config.borderRadius);
            container.style.setProperty('--ak-panel-width', this.config.panelWidth);

            // Floating Button
            const button = document.createElement('button');
            button.id = 'accessibility-kit-button';
            button.className = 'ak-button';
            button.setAttribute('aria-label', this.t('buttonAriaLabel'));
            button.setAttribute('aria-expanded', 'false');
            button.setAttribute('aria-controls', 'accessibility-kit-panel');
            button.innerHTML = this.getSVGIcon('accessibility') + `<span class="ak-ripple"></span>`;
            button.title = this.t('buttonLabel');

            // Panel
            const panel = document.createElement('div');
            panel.id = 'accessibility-kit-panel';
            panel.className = 'ak-panel';
            panel.setAttribute('role', 'dialog');
            panel.setAttribute('aria-modal', 'true');
            panel.setAttribute('aria-labelledby', 'accessibility-kit-title');
            panel.hidden = true;

            // Panel Header
            const header = document.createElement('div');
            header.className = 'ak-panel-header';

            const headerTop = document.createElement('div');
            headerTop.className = 'ak-panel-header-top';

            const title = document.createElement('h2');
            title.id = 'accessibility-kit-title';
            title.className = 'ak-panel-title';
            title.textContent = this.t('title');

            const closeBtn = document.createElement('button');
            closeBtn.className = 'ak-close-button';
            closeBtn.setAttribute('aria-label', this.t('closeButton'));
            closeBtn.innerHTML = this.getSVGIcon('close');

            headerTop.appendChild(title);
            headerTop.appendChild(closeBtn);
            header.appendChild(headerTop);

            // Tool Search Input
            /*const searchContainer = document.createElement('div');
            searchContainer.className = 'ak-search-container';
            searchContainer.innerHTML = `
                <span class="ak-search-icon">${this.getSVGIcon('search')}</span>
                <input type="text" id="ak-tool-search" class="ak-search-input" placeholder="${this.t('options.searchPlaceholder') || 'Buscar herramienta...'}" aria-label="Buscar herramienta" />
                <button type="button" class="ak-search-clear" style="display:none;" aria-label="Limpiar búsqueda">&times;</button>
            `;
            header.appendChild(searchContainer);
*/
            // Panel Content
            const content = document.createElement('div');
            content.className = 'ak-panel-content';
            
            panel.appendChild(header);
            panel.appendChild(content);

            // Overlay
            const overlay = document.createElement('div');
            overlay.id = 'accessibility-kit-overlay';
            overlay.className = 'ak-overlay';
            overlay.hidden = true;

            // Reading Guides
            const readingGuide = document.createElement('div');
            readingGuide.id = 'ak-reading-guide';
            readingGuide.className = 'ak-reading-guide';
            readingGuide.hidden = true;

            const readingMask = document.createElement('div');
            readingMask.id = 'ak-reading-mask';
            readingMask.className = 'ak-reading-mask';
            readingMask.hidden = true;

            // Toast feedback
            const toast = document.createElement('div');
            toast.className = 'ak-toast';
            toast.setAttribute('aria-live', 'polite');
            toast.hidden = true;

            // Assemble
            container.appendChild(button);
            container.appendChild(panel);
            container.appendChild(overlay);
            container.appendChild(toast);
            
            document.body.appendChild(container);
            document.body.appendChild(readingGuide);
            document.body.appendChild(readingMask);

            // Store DOM references
            this.elements.container = container;
            this.elements.button = button;
            this.elements.panel = panel;
            this.elements.overlay = overlay;
            this.elements.readingGuide = readingGuide;
            this.elements.readingMask = readingMask;
            this.elements.toast = toast;
            this.elements.content = content;

            // Render panel items
            this.renderContent();
        }

        renderContent(searchQuery = '') {
            const t = this.translations[this.state.currentLanguage].options;
            const sec = this.translations[this.state.currentLanguage].sections;
            const q = searchQuery.toLowerCase().trim();

            // Create sections array to filter and render
            const sections = [
                {
                    id: 'favorites',
                    title: this.t('sections.favorites') || 'Favoritos ⭐',
                    controls: [] // dynamically populated
                },
                {
                    id: 'quick-access',
                    title: this.t('sections.quickAccess') || 'Accesos Rápidos ⚡',
                    controls: [] // dynamically populated
                },
                {
                    id: 'text',
                    title: sec.text,
                    controls: [
                        { action: 'increaseFontSize', icon: 'plus', text: t.increaseFontSize, tooltip: 'Aumenta el tamaño de la fuente para mejor legibilidad' },
                        { action: 'decreaseFontSize', icon: 'minus', text: t.decreaseFontSize, tooltip: 'Disminuye el tamaño de la fuente si es muy grande' },
                        { action: 'resetFontSize', icon: 'reset', text: t.resetFontSize, tooltip: 'Restablece la tipografía al tamaño predeterminado' }
                    ]
                },
                {
                    id: 'contrast',
                    title: sec.contrast,
                    controls: [
                        { action: 'setContrast', value: 'normal', icon: 'contrast', text: t.normalContrast, tooltip: 'Contraste predeterminado del sitio' },
                        { action: 'setContrast', value: 'high', icon: 'contrast-high', text: t.highContrast, tooltip: 'Contraste alto para personas con baja visión' },
                        { action: 'setContrast', value: 'enhanced', icon: 'contrast-enhanced', text: t.enhancedContrast, tooltip: 'Colores con contraste medio y tono cálido' },
                        { action: 'setContrast', value: 'dark', icon: 'moon', text: t.darkMode, tooltip: 'Fondo oscuro para evitar fatiga visual' }
                    ]
                },
                {
                    id: 'vision',
                    title: sec.vision,
                    controls: [
                        { action: 'toggleGrayscale', icon: 'image', text: t.grayscale, isActive: this.state.grayscale, tooltip: 'Convierte el sitio a escala de grises para mitigar distracción' },
                        { action: 'toggleInvertColors', icon: 'invert', text: t.invertColors, isActive: this.state.invertColors, tooltip: 'Invierte la gama cromática' },
                        { action: 'toggleHighlightLinks', icon: 'link', text: t.highlightLinks, isActive: this.state.highlightLinks, tooltip: 'Resalta con bordes amarillos/azules todos los enlaces clickeables' },
                        { action: 'toggleHighlightHeadings', icon: 'heading', text: t.highlightHeadings, isActive: this.state.highlightHeadings, tooltip: 'Añade fondo y bordes marcados a todos los encabezados' }
                    ]
                },
                {
                    id: 'reading',
                    title: sec.reading,
                    controls: [
                        { action: 'toggleDyslexiaFont', icon: 'font', text: t.dyslexiaFont, isActive: this.state.dyslexiaFont, tooltip: 'Cambia a Atkinson Hyperlegible para facilitar la lectura' },
                        { action: 'toggleReadingGuide', icon: 'guide', text: t.readingGuide, isActive: this.state.readingGuide, tooltip: 'Muestra una línea guía horizontal que sigue tu cursor' },
                        { action: 'toggleReadingMask', icon: 'mask', text: t.readingMask, isActive: this.state.readingMask, tooltip: 'Oscurece la pantalla dejando un haz translúcido sobre el cursor' },
                        { action: 'toggleReadingMode', icon: 'book', text: t.readingMode, isActive: this.state.readingMode, tooltip: 'Simplifica la página ocultando distractores (menús, banners)' }
                    ]
                },
                {
                    id: 'spacing',
                    title: this.t('sections.spacing') || 'Ajustes de Espaciado',
                    controls: [
                        { action: 'adjustSpacing', value: 'letter-increase', icon: 'spacing', text: 'Espaciado letras (+)', tooltip: 'Incrementa el espacio entre letras' },
                        { action: 'adjustSpacing', value: 'letter-reset', icon: 'reset', text: 'Restablecer letras', tooltip: 'Restablece el espaciado de letras' },
                        { action: 'adjustSpacing', value: 'word-increase', icon: 'spacing', text: 'Espaciado palabras (+)', tooltip: 'Incrementa el espacio entre palabras' },
                        { action: 'adjustSpacing', value: 'word-reset', icon: 'reset', text: 'Restablecer palabras', tooltip: 'Restablece el espaciado de palabras' },
                        { action: 'adjustSpacing', value: 'line-increase', icon: 'spacing', text: 'Altura de línea (+)', tooltip: 'Incrementa el interlineado de textos' },
                        { action: 'adjustSpacing', value: 'line-reset', icon: 'reset', text: 'Restablecer interlineado', tooltip: 'Restablece la altura de línea' }
                    ]
                },
                {
                    id: 'cursor',
                    title: this.t('sections.cursor') || 'Cursor y Navegación',
                    controls: [
                        { action: 'setCursorSize', value: 'normal', icon: 'cursor', text: t.normalCursor || 'Cursor normal', tooltip: 'Usa el cursor predeterminado del sistema' },
                        { action: 'setCursorSize', value: 'large', icon: 'cursor', text: t.largeCursor || 'Cursor grande', tooltip: 'Aumenta el tamaño del cursor a un nivel medio' },
                        { action: 'setCursorSize', value: 'extra-large', icon: 'cursor', text: t.extraLargeCursor || 'Cursor Extra Grande', tooltip: 'Aumenta el cursor al tamaño máximo' },
                        { action: 'togglePauseAnimations', icon: 'pause', text: t.pauseAnimations, isActive: this.state.pauseAnimations, tooltip: 'Detiene todos los elementos en movimiento del sitio web' },
                        { action: 'toggleHideImages', icon: 'image', text: t.hideImages, isActive: this.state.hideImages, tooltip: 'Reemplaza imágenes con placeholders sencillos' }
                    ]
                },
                {
                    id: 'audio',
                    title: sec.audio,
                    controls: [
                        { action: 'startReading', icon: 'play', text: t.startReading, tooltip: 'Comienza a leer en voz alta el contenido del sitio web' },
                        { action: 'pauseReading', icon: 'pause', text: t.pauseReading, tooltip: 'Pausa la lectura actual' },
                        { action: 'stopReading', icon: 'stop', text: t.stopReading, tooltip: 'Detiene y cancela la lectura activa' }
                    ]
                },
                {
                    id: 'keyboard',
                    title: sec.keyboard,
                    controls: [
                        { action: 'toggleFocusVisibility', icon: 'eye', text: t.visibleFocus, isActive: this.state.focusVisibility, tooltip: 'Añade un borde azul ultra visible sobre el elemento activo del teclado' }
                    ]
                },
                {
                    id: 'config',
                    title: this.t('sections.options') || 'Configuración',
                    controls: [
                        { action: 'resetAll', icon: 'reset', text: t.resetAll, tooltip: 'Apaga todas las herramientas y restaura el sitio a su estado original' }
                    ]
                }
            ];

            // Resolve Favorites dynamically
            const allItems = [];
            sections.forEach(s => {
                if (s.id !== 'favorites' && s.id !== 'quick-access') {
                    s.controls.forEach(c => {
                        allItems.push(c);
                    });
                }
            });

            // Populate Favorites
            if (this.state.favorites && this.state.favorites.length > 0) {
                const favSection = sections.find(s => s.id === 'favorites');
                this.state.favorites.forEach(actionKey => {
                    const found = allItems.find(item => {
                        if (item.value) {
                            return `${item.action}:${item.value}` === actionKey;
                        }
                        return item.action === actionKey;
                    });
                    if (found) {
                        favSection.controls.push({ ...found, isFav: true });
                    }
                });
            }

            // Populate Quick Access (Top 4 most clicked)
            const quickAccessSection = sections.find(s => s.id === 'quick-access');
            const sortedCounts = Object.entries(this.state.clickCounts)
                .sort((a, b) => b[1] - a[1])
                .slice(0, 4)
                .filter(entry => entry[1] > 0);
            
            sortedCounts.forEach(([actionKey]) => {
                const found = allItems.find(item => {
                    if (item.value) {
                        return `${item.action}:${item.value}` === actionKey;
                    }
                    return item.action === actionKey;
                });
                if (found && !quickAccessSection.controls.some(c => c.action === found.action && c.value === found.value)) {
                    quickAccessSection.controls.push(found);
                }
            });

            // Generate HTML
            let htmlContent = '';

            sections.forEach(section => {
                // If it is Favorites or Quick Access and empty, hide it unless searching
                if ((section.id === 'favorites' || section.id === 'quick-access') && section.controls.length === 0) {
                    return;
                }

                // Filter controls if search query active
                let filteredControls = section.controls;
                if (q) {
                    filteredControls = section.controls.filter(c => 
                        c.text.toLowerCase().includes(q) || 
                        c.tooltip.toLowerCase().includes(q)
                    );
                }

                if (filteredControls.length === 0) {
                    return; // hide empty sections during search
                }

                htmlContent += `
                    <div class="ak-section" data-section-id="${section.id}">
                        <h3 class="ak-section-title">${section.title}</h3>
                        <div class="ak-controls">
                `;

                filteredControls.forEach(ctrl => {
                    const actionAttr = ctrl.action;
                    const valueAttr = ctrl.value ? `data-value="${ctrl.value}"` : '';
                    const keyVal = ctrl.value ? `${ctrl.action}:${ctrl.value}` : ctrl.action;
                    
                    // Determine if active
                    let activeClass = '';
                    if (ctrl.isActive) {
                        activeClass = 'active';
                    } else if (ctrl.action === 'setContrast' && this.state.contrast === ctrl.value) {
                        activeClass = 'active';
                    } else if (ctrl.action === 'setCursorSize' && this.state.cursorSize === ctrl.value) {
                        activeClass = 'active';
                    }

                    const isFavorite = this.state.favorites.includes(keyVal);
                    const starIcon = `
                        <button class="ak-star-btn ${isFavorite ? 'fav-active' : ''}" data-fav-key="${keyVal}" aria-label="Añadir a favoritos" title="Favorito">
                            ${this.getSVGIcon('star')}
                        </button>
                    `;

                    htmlContent += `
                        <div class="ak-control-wrapper">
                            <button class="ak-control-button ${activeClass}" data-action="${actionAttr}" ${valueAttr} title="${ctrl.text}">
                                ${this.getSVGIcon(ctrl.icon)}
                                <span>${ctrl.text}</span>
                                <span class="ak-tooltip-text">${ctrl.tooltip}</span>
                            </button>
                            ${ctrl.action !== 'resetAll' && ctrl.action !== 'startReading' && ctrl.action !== 'stopReading' && ctrl.action !== 'pauseReading' ? starIcon : ''}
                        </div>
                    `;
                });

                htmlContent += `
                        </div>
                    </div>
                `;
            });

            if (htmlContent === '') {
                htmlContent = `
                    <div class="ak-no-results">
                        <p>${this.state.currentLanguage === 'es' ? 'No se encontraron herramientas.' : 'No tools found.'}</p>
                    </div>
                `;
            }

            this.elements.content.innerHTML = htmlContent;
        }

        setupEventListeners() {
            // Toggle panel
            this.elements.button.addEventListener('click', (e) => {
                e.stopPropagation();
                this.togglePanel();
            });

            // Close button inside header
            this.elements.panel.querySelector('.ak-close-button').addEventListener('click', () => {
                this.closePanel();
            });

            // Click overlay to close
            this.elements.overlay.addEventListener('click', () => {
                this.closePanel();
            });

            // Search input handler
            const searchInput = this.elements.panel.querySelector('#ak-tool-search');
            const searchClear = this.elements.panel.querySelector('.ak-search-clear');

            searchInput.addEventListener('input', (e) => {
                const val = e.target.value;
                if (val.trim().length > 0) {
                    searchClear.style.display = 'block';
                } else {
                    searchClear.style.display = 'none';
                }
                this.renderContent(val);
            });

            searchClear.addEventListener('click', () => {
                searchInput.value = '';
                searchClear.style.display = 'none';
                this.renderContent('');
                searchInput.focus();
            });

            // Delegated controls click event
            this.elements.panel.addEventListener('click', (e) => {
                // Star button
                const starBtn = e.target.closest('.ak-star-btn');
                if (starBtn) {
                    e.stopPropagation();
                    const favKey = starBtn.dataset.favKey;
                    this.toggleFavorite(favKey);
                    return;
                }

                // Control Button
                const btn = e.target.closest('.ak-control-button');
                if (!btn) return;

                const action = btn.dataset.action;
                const value = btn.dataset.value;

                // Track click usage
                const keyVal = value ? `${action}:${value}` : action;
                this.state.clickCounts[keyVal] = (this.state.clickCounts[keyVal] || 0) + 1;

                this.handleAction(action, value, btn);
            });

            // Keyboard Escape
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape' && this.state.isOpen) {
                    this.closePanel();
                }
            });

            // Click outside to close
            document.addEventListener('click', (e) => {
                if (this.state.isOpen && !this.elements.container.contains(e.target)) {
                    this.closePanel();
                }
            });
        }

        handleAction(action, value, element) {
            // Visual skeleton/spinner load effect simulation
            this.elements.content.classList.add('ak-loading');
            
            setTimeout(() => {
                switch (action) {
                    case 'increaseFontSize':
                        this.adjustFontSize(15);
                        break;
                    case 'decreaseFontSize':
                        this.adjustFontSize(-15);
                        break;
                    case 'resetFontSize':
                        this.resetFontSize();
                        break;
                    case 'setContrast':
                        this.setContrast(value);
                        break;
                    case 'toggleGrayscale':
                        this.toggleGrayscale();
                        break;
                    case 'toggleInvertColors':
                        this.toggleInvertColors();
                        break;
                    case 'toggleHighlightLinks':
                        this.toggleHighlightLinks();
                        break;
                    case 'toggleHighlightHeadings':
                        this.toggleHighlightHeadings();
                        break;
                    case 'toggleDyslexiaFont':
                        this.toggleDyslexiaFont();
                        break;
                    case 'toggleReadingGuide':
                        this.toggleReadingGuide();
                        break;
                    case 'toggleReadingMask':
                        this.toggleReadingMask();
                        break;
                    case 'toggleReadingMode':
                        this.toggleReadingMode();
                        break;
                    case 'togglePauseAnimations':
                        this.togglePauseAnimations();
                        break;
                    case 'toggleHideImages':
                        this.toggleHideImages();
                        break;
                    case 'toggleFocusVisibility':
                        this.toggleFocusVisibility();
                        break;
                    case 'adjustSpacing':
                        this.adjustSpacing(value);
                        break;
                    case 'setCursorSize':
                        this.setCursorSize(value);
                        break;
                    case 'startReading':
                        this.startReading();
                        break;
                    case 'pauseReading':
                        this.pauseReading();
                        break;
                    case 'stopReading':
                        this.stopReading();
                        break;
                    case 'resetAll':
                        this.resetAll();
                        break;
                }

                // Refresh panel layout keeping search state if exists
                const searchVal = this.elements.panel.querySelector('#ak-tool-search').value;
                this.renderContent(searchVal);
                
                this.elements.content.classList.remove('ak-loading');
                this.savePreferences();
            }, 180);
        }

        // --- Core actions ---

        showToast(message) {
            const toast = this.elements.toast;
            toast.textContent = message;
            toast.hidden = false;
            toast.classList.add('show');
            setTimeout(() => {
                toast.classList.remove('show');
                setTimeout(() => { toast.hidden = true; }, 300);
            }, 2500);
        }

        toggleFavorite(keyVal) {
            const idx = this.state.favorites.indexOf(keyVal);
            if (idx > -1) {
                this.state.favorites.splice(idx, 1);
                this.showToast('Eliminado de favoritos ⭐');
            } else {
                this.state.favorites.push(keyVal);
                this.showToast('Añadido a favoritos ⭐');
            }
            const searchVal = this.elements.panel.querySelector('#ak-tool-search').value;
            this.renderContent(searchVal);
            this.savePreferences();
        }

        adjustFontSize(delta) {
            this.state.textScale = Math.max(80, Math.min(220, this.state.textScale + delta));
            this.applyFontSize();
            this.showToast(`Tamaño del texto: ${this.state.textScale}%`);
        }

        resetFontSize() {
            this.state.textScale = 100;
            this.applyFontSize();
            this.showToast('Tamaño del texto restablecido');
        }

        applyFontSize() {
            const scale = this.state.textScale / 100;
            document.documentElement.style.setProperty('--ak-font-scale', scale);
            // Dynamic resizing of font elements globally
            document.documentElement.style.fontSize = `${16 * scale}px`;
        }

        setContrast(mode) {
            document.documentElement.setAttribute('data-ak-contrast', mode);
            this.state.contrast = mode;
            this.showToast(`Contraste: ${mode}`);
        }

        toggleGrayscale() {
            this.state.grayscale = !this.state.grayscale;
            document.documentElement.setAttribute('data-ak-grayscale', this.state.grayscale);
            this.showToast(this.state.grayscale ? 'Escala de grises activada' : 'Escala de grises desactivada');
        }

        toggleInvertColors() {
            this.state.invertColors = !this.state.invertColors;
            document.documentElement.setAttribute('data-ak-invert', this.state.invertColors);
            this.showToast(this.state.invertColors ? 'Inversión de colores activada' : 'Inversión de colores desactivada');
        }

        toggleHighlightLinks() {
            this.state.highlightLinks = !this.state.highlightLinks;
            document.documentElement.setAttribute('data-ak-highlight-links', this.state.highlightLinks);
            this.showToast(this.state.highlightLinks ? 'Resaltar enlaces activado' : 'Resaltar enlaces desactivado');
        }

        toggleHighlightHeadings() {
            this.state.highlightHeadings = !this.state.highlightHeadings;
            document.documentElement.setAttribute('data-ak-highlight-headings', this.state.highlightHeadings);
            this.showToast(this.state.highlightHeadings ? 'Resaltar títulos activado' : 'Resaltar títulos desactivado');
        }

        toggleDyslexiaFont() {
            this.state.dyslexiaFont = !this.state.dyslexiaFont;
            document.documentElement.setAttribute('data-ak-dyslexia-font', this.state.dyslexiaFont);
            this.showToast(this.state.dyslexiaFont ? 'Tipografía para dislexia activada' : 'Tipografía para dislexia desactivada');
        }

        adjustSpacing(type) {
            switch (type) {
                case 'letter-increase':
                    this.state.letterSpacing = Math.min(8, this.state.letterSpacing + 2);
                    break;
                case 'letter-reset':
                    this.state.letterSpacing = 0;
                    break;
                case 'word-increase':
                    this.state.wordSpacing = Math.min(16, this.state.wordSpacing + 4);
                    break;
                case 'word-reset':
                    this.state.wordSpacing = 0;
                    break;
                case 'line-increase':
                    this.state.lineHeight = Math.min(2.8, this.state.lineHeight + 0.3);
                    break;
                case 'line-reset':
                    this.state.lineHeight = 1.5;
                    break;
            }
            this.applySpacing();
            this.showToast('Ajustes de espaciado aplicados');
        }

        applySpacing() {
            document.documentElement.style.setProperty('--ak-letter-spacing', `${this.state.letterSpacing}px`);
            document.documentElement.style.setProperty('--ak-word-spacing', `${this.state.wordSpacing}px`);
            document.documentElement.style.setProperty('--ak-line-height', this.state.lineHeight);
            
            // Set attributes to apply spacing using global selector
            document.documentElement.setAttribute('data-ak-spacing-active', 
                (this.state.letterSpacing > 0 || this.state.wordSpacing > 0 || this.state.lineHeight > 1.5) ? 'true' : 'false'
            );
        }

        setCursorSize(size) {
            this.state.cursorSize = size;
            document.documentElement.setAttribute('data-ak-cursor', size);
            this.showToast(`Tamaño del cursor: ${size}`);
        }

        toggleReadingGuide() {
            this.state.readingGuide = !this.state.readingGuide;
            this.elements.readingGuide.hidden = !this.state.readingGuide;
            if (this.state.readingGuide) {
                this.updateGuideFn = (e) => {
                    this.elements.readingGuide.style.top = `${e.clientY}px`;
                };
                document.addEventListener('mousemove', this.updateGuideFn);
                this.showToast('Guía de lectura activada');
            } else {
                if (this.updateGuideFn) {
                    document.removeEventListener('mousemove', this.updateGuideFn);
                }
                this.showToast('Guía de lectura desactivada');
            }
        }

        toggleReadingMask() {
            this.state.readingMask = !this.state.readingMask;
            this.elements.readingMask.hidden = !this.state.readingMask;
            if (this.state.readingMask) {
                this.updateMaskFn = (e) => {
                    this.elements.readingMask.style.backgroundImage = `radial-gradient(circle 90px at ${e.clientX}px ${e.clientY}px, transparent 100%, rgba(0, 0, 0, 0.75) 100%)`;
                };
                document.addEventListener('mousemove', this.updateMaskFn);
                this.showToast('Máscara de lectura activada');
            } else {
                if (this.updateMaskFn) {
                    document.removeEventListener('mousemove', this.updateMaskFn);
                }
                this.showToast('Máscara de lectura desactivada');
            }
        }

        toggleReadingMode() {
            this.state.readingMode = !this.state.readingMode;
            document.documentElement.setAttribute('data-ak-reading-mode', this.state.readingMode);
            this.showToast(this.state.readingMode ? 'Modo lectura activado' : 'Modo lectura desactivado');
        }

        togglePauseAnimations() {
            this.state.pauseAnimations = !this.state.pauseAnimations;
            document.documentElement.setAttribute('data-ak-pause-animations', this.state.pauseAnimations);
            this.showToast(this.state.pauseAnimations ? 'Animaciones pausadas' : 'Animaciones normales');
        }

        toggleHideImages() {
            this.state.hideImages = !this.state.hideImages;
            document.documentElement.setAttribute('data-ak-hide-images', this.state.hideImages);
            this.showToast(this.state.hideImages ? 'Imágenes ocultas' : 'Imágenes visibles');
        }

        toggleFocusVisibility() {
            this.state.focusVisibility = !this.state.focusVisibility;
            document.documentElement.setAttribute('data-ak-focus-visible', this.state.focusVisibility);
            this.showToast(this.state.focusVisibility ? 'Foco visible activado' : 'Foco visible desactivado');
        }

        // --- Speech Synthesis ---

        startReading() {
            if (!('speechSynthesis' in window)) {
                this.showToast('Lectura por voz no soportada');
                return;
            }
            this.stopReading();

            const text = this.extractReadableContent();
            if (!text.trim()) {
                this.showToast('No se encontró texto leíble');
                return;
            }

            const utterance = new SpeechSynthesisUtterance(text);
            utterance.lang = this.state.currentLanguage === 'es' ? 'es-CO' : 'en-US';
            
            utterance.onend = () => {
                this.speechState.isReading = false;
                this.speechState.isPaused = false;
            };

            this.speechState.utterance = utterance;
            this.speechState.isReading = true;
            this.speechState.isPaused = false;

            window.speechSynthesis.speak(utterance);
            this.showToast('Iniciando lectura por voz');
        }

        pauseReading() {
            if (window.speechSynthesis && this.speechState.isReading) {
                window.speechSynthesis.pause();
                this.speechState.isPaused = true;
                this.showToast('Lectura pausada');
            }
        }

        resumeReading() {
            if (window.speechSynthesis && this.speechState.isPaused) {
                window.speechSynthesis.resume();
                this.speechState.isPaused = false;
                this.showToast('Lectura reanudada');
            }
        }

        stopReading() {
            if (window.speechSynthesis) {
                window.speechSynthesis.cancel();
                this.speechState.isReading = false;
                this.speechState.isPaused = false;
                this.showToast('Lectura detenida');
            }
        }

        extractReadableContent() {
            const bodyClone = document.body.cloneNode(true);
            // Strip out elements that shouldn't be read
            const excluded = bodyClone.querySelectorAll('script, style, nav, header, footer, #accessibility-kit-container, .ak-*, [aria-hidden="true"]');
            excluded.forEach(el => el.remove());
            return bodyClone.innerText || bodyClone.textContent || '';
        }

        // --- Panel State ---

        togglePanel() {
            if (this.state.isOpen) {
                this.closePanel();
            } else {
                this.openPanel();
            }
        }

        openPanel() {
            this.state.isOpen = true;
            this.elements.panel.hidden = false;
            this.elements.overlay.hidden = false;
            this.elements.button.setAttribute('aria-expanded', 'true');
            this.elements.panel.classList.add('ak-open');
            this.elements.overlay.classList.add('ak-open');

            // Set focus to the search input
            setTimeout(() => {
                const search = this.elements.panel.querySelector('#ak-tool-search');
                if (search) search.focus();
            }, 250);
        }

        closePanel() {
            this.state.isOpen = false;
            this.elements.panel.classList.remove('ak-open');
            this.elements.overlay.classList.remove('ak-open');
            this.elements.button.setAttribute('aria-expanded', 'false');

            setTimeout(() => {
                this.elements.panel.hidden = true;
                this.elements.overlay.hidden = true;
                this.elements.button.focus();
            }, 300);
        }

        resetAll() {
            this.state.textScale = 100;
            this.state.contrast = 'normal';
            this.state.grayscale = false;
            this.state.invertColors = false;
            this.state.highlightLinks = false;
            this.state.highlightHeadings = false;
            this.state.dyslexiaFont = false;
            this.state.letterSpacing = 0;
            this.state.wordSpacing = 0;
            this.state.lineHeight = 1.5;
            this.state.cursorSize = 'normal';
            this.state.readingGuide = false;
            this.state.readingMask = false;
            this.state.pauseAnimations = false;
            this.state.focusVisibility = true;
            this.state.hideImages = false;
            this.state.readingMode = false;

            this.stopReading();

            // Reset guides and masks
            this.elements.readingGuide.hidden = true;
            this.elements.readingMask.hidden = true;
            if (this.updateGuideFn) document.removeEventListener('mousemove', this.updateGuideFn);
            if (this.updateMaskFn) document.removeEventListener('mousemove', this.updateMaskFn);

            // Clean classes and styles
            document.documentElement.removeAttribute('data-ak-contrast');
            document.documentElement.removeAttribute('data-ak-grayscale');
            document.documentElement.removeAttribute('data-ak-invert');
            document.documentElement.removeAttribute('data-ak-highlight-links');
            document.documentElement.removeAttribute('data-ak-highlight-headings');
            document.documentElement.removeAttribute('data-ak-dyslexia-font');
            document.documentElement.removeAttribute('data-ak-reading-mode');
            document.documentElement.removeAttribute('data-ak-pause-animations');
            document.documentElement.removeAttribute('data-ak-hide-images');
            document.documentElement.removeAttribute('data-ak-focus-visible');
            document.documentElement.removeAttribute('data-ak-spacing-active');
            document.documentElement.removeAttribute('data-ak-cursor');

            document.documentElement.style.setProperty('--ak-font-scale', '1');
            document.documentElement.style.setProperty('--ak-letter-spacing', '0px');
            document.documentElement.style.setProperty('--ak-word-spacing', '0px');
            document.documentElement.style.setProperty('--ak-line-height', '1.5');
            document.documentElement.style.fontSize = '';

            this.showToast('Todas las preferencias han sido restauradas');
            this.savePreferences();
        }

        // --- Persistence ---

        savePreferences() {
            if (!this.config.savePreferences) return;
            const prefs = {
                textScale: this.state.textScale,
                contrast: this.state.contrast,
                grayscale: this.state.grayscale,
                invertColors: this.state.invertColors,
                highlightLinks: this.state.highlightLinks,
                highlightHeadings: this.state.highlightHeadings,
                dyslexiaFont: this.state.dyslexiaFont,
                letterSpacing: this.state.letterSpacing,
                wordSpacing: this.state.wordSpacing,
                lineHeight: this.state.lineHeight,
                cursorSize: this.state.cursorSize,
                readingGuide: this.state.readingGuide,
                readingMask: this.state.readingMask,
                pauseAnimations: this.state.pauseAnimations,
                focusVisibility: this.state.focusVisibility,
                hideImages: this.state.hideImages,
                readingMode: this.state.readingMode,
                language: this.state.currentLanguage,
                favorites: this.state.favorites,
                clickCounts: this.state.clickCounts
            };
            try {
                localStorage.setItem('ak-preferences', JSON.stringify(prefs));
            } catch (e) {
                console.warn('LocalStorage save failed:', e);
            }
        }

        loadPreferences() {
            try {
                const raw = localStorage.getItem('ak-preferences');
                if (raw) {
                    const parsed = JSON.parse(raw);
                    if (parsed && typeof parsed === 'object') {
                        Object.assign(this.state, parsed);
                    }
                }
            } catch (e) {
                console.warn('LocalStorage load failed:', e);
            }
        }

        applySavedSettings() {
            this.applyFontSize();
            this.applySpacing();
            document.documentElement.setAttribute('data-ak-contrast', this.state.contrast);
            document.documentElement.setAttribute('data-ak-cursor', this.state.cursorSize);
            if (this.state.grayscale) document.documentElement.setAttribute('data-ak-grayscale', 'true');
            if (this.state.invertColors) document.documentElement.setAttribute('data-ak-invert', 'true');
            if (this.state.highlightLinks) document.documentElement.setAttribute('data-ak-highlight-links', 'true');
            if (this.state.highlightHeadings) document.documentElement.setAttribute('data-ak-highlight-headings', 'true');
            if (this.state.dyslexiaFont) document.documentElement.setAttribute('data-ak-dyslexia-font', 'true');
            if (this.state.readingMode) document.documentElement.setAttribute('data-ak-reading-mode', 'true');
            if (this.state.pauseAnimations) document.documentElement.setAttribute('data-ak-pause-animations', 'true');
            if (this.state.hideImages) document.documentElement.setAttribute('data-ak-hide-images', 'true');
            if (this.state.focusVisibility) document.documentElement.setAttribute('data-ak-focus-visible', 'true');
        }

        // --- Accessibility & Keyboard Order ---

        setupKeyboardShortcuts() {
            document.addEventListener('keydown', (e) => {
                if (e.altKey && e.key.toLowerCase() === 'a') {
                    e.preventDefault();
                    this.togglePanel();
                }
            });
        }

        initializeFocusManagement() {
            // Enhanced active element highlighting
            document.addEventListener('focusin', (e) => {
                if (this.state.focusVisibility && e.target.classList) {
                    e.target.classList.add('ak-focused');
                }
            });
            document.addEventListener('focusout', (e) => {
                if (e.target.classList) {
                    e.target.classList.remove('ak-focused');
                }
            });
        }

        setupMutationObserver() {
            const observer = new MutationObserver(() => {
                // Future observers can hook here
            });
            observer.observe(document.body, { childList: true, subtree: true });
        }

        t(key) {
            const lang = this.translations[this.state.currentLanguage] || this.translations.es;
            const parts = key.split('.');
            let value = lang;
            for (const part of parts) {
                value = value ? value[part] : null;
            }
            return value || key;
        }

        getSVGIcon(name) {
            const icons = {
                accessibility: '<svg viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="2"/><path d="M12 10c-1.1 0-2 .9-2 2v5h4v-5c0-1.1-.9-2-2-2m7 7v-4c0-.5-.5-1-1-1h-4v3h3v3h2m-12 0v-3h3v-3h-4c-.5 0-1 .5-1 1v4h2z"/></svg>',
                close: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
                plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>',
                minus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/></svg>',
                reset: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M3 21v-5h5"/></svg>',
                contrast: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2m0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8m3.5-9c.83 0 1.5-.67 1.5-1.5S16.33 8 15.5 8 14 8.67 14 9.5s.67 1.5 1.5 1.5z"/></svg>',
                'contrast-high': '<svg viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="10" fill="black"/><circle cx="12" cy="12" r="10" fill="none" stroke="white" stroke-width="2"/></svg>',
                'contrast-enhanced': '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2m0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/></svg>',
                moon: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M21.64 13a1 1 0 0 0-1.05-.14 8 8 0 1 1 1.05.14z"/></svg>',
                image: '<svg viewBox="0 0 24 24" fill="currentColor"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>',
                invert: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2m0 18v-8H4c0-4.41 3.59-8 8-8v16z"/></svg>',
                link: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>',
                heading: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M4 4h4v16H4V4zm12 0c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2s2-.9 2-2V6c0-1.1-.9-2-2-2zm-6 4h4v12h-4V8z"/></svg>',
                font: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M9.6 14h4.8L12 8l-2.4 6zm6.6 6H8.4l-.8 2H4.4L12 2h2.4l7.6 20h-3.2l-.8-2z"/></svg>',
                spacing: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M3 21h18v-2H3v2zm0-8h18v-2H3v2zm0-8h18V3H3v2zm19-2v16h2V3h-2z"/></svg>',
                guide: '<svg viewBox="0 0 24 24" fill="currentColor"><line x1="3" y1="12" x2="21" y2="12" stroke="currentColor" stroke-width="2"/></svg>',
                mask: '<svg viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="8" fill="currentColor" opacity="0.5"/><circle cx="12" cy="12" r="4" fill="none"/></svg>',
                book: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>',
                cursor: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8.5 5L2 13h5v8h2v-8h5l-5.5-8zm7 7h2v9h-2z"/></svg>',
                pause: '<svg viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>',
                play: '<svg viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>',
                stop: '<svg viewBox="0 0 24 24" fill="currentColor"><rect x="4" y="4" width="16" height="16"/></svg>',
                eye: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>',
                star: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>',
                search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>'
            };
            return icons[name] || icons.accessibility;
        }

        static init(options = {}) {
            if (window.AccessibilityKitInstance) {
                return window.AccessibilityKitInstance;
            }
            window.AccessibilityKitInstance = new AccessibilityKit(options);
            return window.AccessibilityKitInstance;
        }

        static destroy() {
            if (window.AccessibilityKitInstance) {
                const instance = window.AccessibilityKitInstance;
                instance.elements.container.remove();
                instance.elements.readingGuide.remove();
                instance.elements.readingMask.remove();
                delete window.AccessibilityKitInstance;
            }
        }
    }

    // Translations object
    AccessibilityKit.prototype.translations = {
        es: {
            buttonLabel: 'Accesibilidad',
            buttonAriaLabel: 'Abrir panel de accesibilidad',
            closeButton: 'Cerrar',
            title: 'Panel de Accesibilidad',
            sections: {
                text: 'Texto',
                contrast: 'Contraste',
                vision: 'Visión',
                reading: 'Lectura',
                keyboard: 'Teclado',
                focus: 'Foco',
                audio: 'Audio'
            },
            options: {
                loaded: 'Kit de accesibilidad cargado correctamente',
                searchPlaceholder: 'Buscar herramienta...',
                increaseFontSize: 'Aumentar tamaño',
                decreaseFontSize: 'Disminuir tamaño',
                resetFontSize: 'Restablecer tamaño',
                highContrast: 'Alto contraste',
                enhancedContrast: 'Contraste mejorado',
                darkMode: 'Modo oscuro accesible',
                normalContrast: 'Contraste normal',
                grayscale: 'Escala de grises',
                invertColors: 'Invertir colores',
                highlightLinks: 'Resaltar enlaces',
                highlightHeadings: 'Resaltar títulos',
                dyslexiaFont: 'Tipografía dislexia',
                readingGuide: 'Guía de lectura',
                readingMask: 'Máscara de lectura',
                pauseAnimations: 'Pausar animaciones',
                visibleFocus: 'Foco visible',
                startReading: 'Iniciar lectura',
                pauseReading: 'Pausar lectura',
                resumeReading: 'Continuar lectura',
                stopReading: 'Detener lectura',
                hideImages: 'Ocultar imágenes',
                readingMode: 'Modo lectura',
                resetAll: 'Restablecer todo'
            }
        },
        en: {
            buttonLabel: 'Accessibility',
            buttonAriaLabel: 'Open accessibility panel',
            closeButton: 'Close',
            title: 'Accessibility Panel',
            sections: {
                favorites: 'My Favorites ⭐',
                quickAccess: 'Most Used ⚡',
                text: 'Text',
                contrast: 'Contrast',
                vision: 'Vision',
                reading: 'Reading',
                keyboard: 'Keyboard',
                focus: 'Focus',
                audio: 'Audio'
            },
            options: {
                loaded: 'Accessibility kit loaded successfully',
                searchPlaceholder: 'Search tools...',
                increaseFontSize: 'Increase size',
                decreaseFontSize: 'Decrease size',
                resetFontSize: 'Reset size',
                highContrast: 'High contrast',
                enhancedContrast: 'Enhanced contrast',
                darkMode: 'Accessible dark mode',
                normalContrast: 'Normal contrast',
                grayscale: 'Grayscale',
                invertColors: 'Invert colors',
                highlightLinks: 'Highlight links',
                highlightHeadings: 'Highlight headings',
                dyslexiaFont: 'Dyslexia font',
                readingGuide: 'Reading guide',
                readingMask: 'Reading mask',
                pauseAnimations: 'Pause animations',
                visibleFocus: 'Visible focus',
                startReading: 'Start reading',
                pauseReading: 'Pause reading',
                resumeReading: 'Resume reading',
                stopReading: 'Stop reading',
                hideImages: 'Hide images',
                readingMode: 'Reading mode',
                resetAll: 'Reset all'
            }
        }
    };

    window.AccessibilityKit = AccessibilityKit;
})(window);
