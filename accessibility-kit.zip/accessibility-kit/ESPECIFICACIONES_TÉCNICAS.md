# 🏗️ ESPECIFICACIONES TÉCNICAS - Accessibility Kit

## Arquitectura y Diseño del Sistema

---

## 📐 Arquitectura General

```
┌─────────────────────────────────────────────────────┐
│  ACCESSIBILITY KIT v1.0.0                           │
├─────────────────────────────────────────────────────┤
│                                                       │
│  ┌──────────────────────────────────────────────┐   │
│  │ AccessibilityKit Class (IIFE)                │   │
│  ├──────────────────────────────────────────────┤   │
│  │                                              │   │
│  │  Constructor(options)                        │   │
│  │  ├─ Configuration Management                │   │
│  │  ├─ State Management                        │   │
│  │  ├─ DOM References                          │   │
│  │  └─ Translations                            │   │
│  │                                              │   │
│  │  Public Methods:                             │   │
│  │  ├─ init()                                  │   │
│  │  ├─ openPanel()                             │   │
│  │  ├─ closePanel()                            │   │
│  │  ├─ togglePanel()                           │   │
│  │  ├─ resetAll()                              │   │
│  │  └─ [Feature Methods]                       │   │
│  │                                              │   │
│  │  Private Methods:                            │   │
│  │  ├─ createDOM()                             │   │
│  │  ├─ setupEventListeners()                   │   │
│  │  ├─ handleAction()                          │   │
│  │  └─ [Internal Methods]                      │   │
│  │                                              │   │
│  │  Static Methods:                             │   │
│  │  ├─ AccessibilityKit.init()                │   │
│  │  └─ AccessibilityKit.destroy()             │   │
│  │                                              │   │
│  └──────────────────────────────────────────────┘   │
│                      │                               │
│      ┌───────────────┼───────────────┐               │
│      ▼               ▼               ▼               │
│  ┌────────┐   ┌──────────┐   ┌──────────────┐       │
│  │CSS     │   │HTML      │   │JavaScript    │       │
│  │Styles  │   │Structure │   │Interactions  │       │
│  └────────┘   └──────────┘   └──────────────┘       │
│                                                       │
└─────────────────────────────────────────────────────┘
```

---

## 🗂️ Estructura de Archivos

```
accessibility-kit/
│
├── 📄 accessibility-kit.js              (42 KB - Fuente)
├── 📄 accessibility-kit.min.js          (28 KB - Producción)
├── 🎨 accessibility-kit.css             (18 KB - Fuente)
│
├── 📚 Documentación
│   ├── README.md                        (Guía completa)
│   ├── INTEGRACIÓN_RÁPIDA.md           (Setup rápido)
│   ├── AUDITORÍA_TÉCNICA.md           (Testing)
│   ├── ESPECIFICACIONES_TÉCNICAS.md   (Este archivo)
│   └── package.json                    (Metadata)
│
├── 🎨 demo/
│   └── index.html                      (Página de demostración)
│
├── 🎯 icons/                           (Carpeta para futuros iconos)
└── 🔤 fonts/                           (Carpeta para fuentes)
```

---

## 🔧 Componentes del Sistema

### 1. **Módulo Principal (AccessibilityKit)**

```javascript
class AccessibilityKit {
  // ==================== INICIALIZACIÓN ====================
  constructor(options = {})          // Constructor
  init()                              // Inicializar
  
  // ==================== UI ====================
  createDOM()                         // Crear estructura HTML
  renderPanelContent()                // Renderizar controles
  setupEventListeners()               // Event listeners
  handleAction(action, value)         // Manejador de acciones
  
  // ==================== PANEL ====================
  openPanel()                         // Abrir panel
  closePanel()                        // Cerrar panel
  togglePanel()                       // Alternar estado
  updateButtonStates()                // Actualizar UI
  
  // ==================== ACCESIBILIDAD ====================
  adjustFontSize(delta)               // Ajustar texto
  resetFontSize()                     // Resetear texto
  applyFontSize()                     // Aplicar escala
  
  setContrast(mode)                   // Cambiar contraste
  toggleGrayscale()                   // Escala de grises
  toggleInvertColors()                // Invertir colores
  toggleHighlightLinks()              // Resaltar enlaces
  toggleHighlightHeadings()           // Resaltar títulos
  toggleDyslexiaFont()                // Fuente dislexia
  
  toggleReadingGuide()                // Guía de lectura
  updateReadingGuide()                // Actualizar posición
  toggleReadingMask()                 // Máscara lectura
  updateReadingMask()                 // Actualizar posición
  
  toggleReadingMode()                 // Modo lectura
  togglePauseAnimations()             // Pausar animaciones
  toggleHideImages()                  // Ocultar imágenes
  toggleFocusVisibility()             // Foco visible
  
  // ==================== AUDIO ====================
  startReading()                      // Iniciar lectura
  pauseReading()                      // Pausar lectura
  resumeReading()                     // Reanudar lectura
  stopReading()                       // Detener lectura
  extractReadableContent()            // Extraer contenido
  
  // ==================== CONFIGURACIÓN ====================
  resetAll()                          // Resetear todo
  savePreferences()                   // Guardar localStorage
  loadPreferences()                   // Cargar localStorage
  applySavedSettings()                // Aplicar guardados
  
  // ==================== NAVEGACIÓN ====================
  setupKeyboardShortcuts()            // Atajos teclado
  initializeFocusManagement()         // Gestión de foco
  updateFocusableElements()           // Actualizar focusables
  
  // ==================== OBSERVACIÓN ====================
  setupMutationObserver()             // Observar cambios DOM
  
  // ==================== UTILIDADES ====================
  t(key)                              // Traducción
  getSVGIcon(name)                    // Obtener icono SVG
  
  // ==================== ESTÁTICOS ====================
  static init(options)                // Inicializar (singleton)
  static destroy()                    // Destruir instancia
}
```

---

## 🔄 Flujo de Datos

### Inicialización

```
1. Cargar archivos JS/CSS
   ↓
2. Ejecutar constructor AccessibilityKit(options)
   ├─ Configurar opciones
   ├─ Inicializar estado
   ├─ Configurar variables globales
   └─ Cargar traducciones
   ↓
3. Llamar init()
   ├─ Cargar preferencias guardadas
   ├─ Crear estructura HTML
   ├─ Configurar event listeners
   ├─ Aplicar configuración guardada
   ├─ Configurar atajos teclado
   ├─ Inicializar gestión de foco
   └─ Configurar MutationObserver
   ↓
4. ¡Listo!
```

### Acción del Usuario

```
Usuario clicks en botón
   ↓
Evento click capturado
   ↓
togglePanel() ejecutado
   ↓
State.isOpen cambia
   ↓
openPanel() o closePanel()
   ├─ Mostrar/ocultar panel
   ├─ Mostrar/ocultar overlay
   ├─ Actualizar aria-expanded
   └─ Establecer foco
   ↓
Panel visible/oculto
```

### Cambio de Configuración

```
Usuario presiona botón (ej: Alto Contraste)
   ↓
handleAction() ejecutado
   ↓
Acción específica (ej: setContrast('high'))
   ↓
DOM attribute actualizado
   ├─ <html data-ak-contrast="high">
   └─ CSS se aplica automáticamente
   ↓
State actualizado
   ├─ this.state.contrast = 'high'
   └─ Botón marcado como activo
   ↓
Preferencias guardadas
   └─ localStorage.setItem('ak-preferences', ...)
   ↓
Configuración aplicada
```

---

## 🎨 Estado (State Management)

```javascript
this.state = {
  // UI State
  isOpen: false,
  
  // Accessibility Settings
  textScale: 100,                    // 80-200%
  contrast: 'normal',                // normal|high|enhanced|dark
  grayscale: false,
  invertColors: false,
  highlightLinks: false,
  highlightHeadings: false,
  dyslexiaFont: false,
  letterSpacing: 0,
  wordSpacing: 0,
  lineHeight: 1.5,
  cursorSize: 'normal',              // normal|large|extra-large
  readingGuide: false,
  readingMask: false,
  pauseAnimations: false,
  focusVisibility: true,
  hideImages: false,
  readingMode: false,
  
  // Language
  currentLanguage: 'es'              // es|en
};
```

---

## 🎯 Event Handling

### Delegación de Eventos (Optimizado)

```javascript
// ✅ DELEGADO (Eficiente)
this.elements.panel.addEventListener('click', (e) => {
  const button = e.target.closest('.ak-control-button');
  if (!button) return;
  this.handleAction(button.dataset.action, button.dataset.value, button);
});

// En lugar de:
// ❌ INDIVIDUAL (Ineficiente)
buttons.forEach(btn => {
  btn.addEventListener('click', () => { /* ... */ });
});
```

### Tipos de Eventos

```
Button Click          → togglePanel()
Control Button Click  → handleAction()
Keyboard (Alt+A)      → togglePanel()
Keyboard (Escape)     → closePanel()
Click Overlay         → closePanel()
Click Outside Panel   → closePanel()
Focus In              → Marcar como focusado
Focus Out             → Desmarcar focusado
Mouse Move            → Actualizar guía/máscara
DOM Mutations         → Actualizar elementos focusables
```

---

## 🎛️ Gestión de Configuración

### Cargar Configuración

```javascript
loadPreferences() {
  try {
    const prefs = JSON.parse(
      localStorage.getItem('ak-preferences')
    );
    if (prefs) {
      Object.assign(this.state, prefs);
    }
  } catch (e) {
    console.warn('Could not load preferences:', e);
    // Fallback: usar valores por defecto
  }
}
```

### Guardar Configuración

```javascript
savePreferences() {
  if (!this.config.savePreferences) return;
  
  const prefs = {
    textScale: this.state.textScale,
    contrast: this.state.contrast,
    // ... otros valores
  };
  
  try {
    localStorage.setItem('ak-preferences', JSON.stringify(prefs));
  } catch (e) {
    console.warn('Could not save preferences:', e);
  }
}
```

---

## 🌐 Internacionalización (i18n)

```javascript
translations = {
  es: {
    buttonLabel: 'Accesibilidad',
    buttonAriaLabel: 'Abrir panel de accesibilidad',
    closeButton: 'Cerrar',
    title: 'Panel de Accesibilidad',
    sections: {
      text: 'Texto',
      contrast: 'Contraste',
      // ...
    },
    options: {
      increaseFontSize: 'Aumentar tamaño',
      // ...
    }
  },
  en: {
    buttonLabel: 'Accessibility',
    // ...
  }
};

// Acceso
t('buttonLabel')              // 'Accesibilidad'
t('sections.text')            // 'Texto'
t('options.increaseFontSize')  // 'Aumentar tamaño'
```

---

## 🎨 CSS Architecture

### Variables CSS

```css
:root {
  /* Colores */
  --ak-primary: #2563eb;
  --ak-text: #1f2937;
  --ak-background: #ffffff;
  
  /* Glassmorphism */
  --ak-glass-bg: rgba(255, 255, 255, 0.7);
  --ak-glass-blur: 12px;
  
  /* Sombras */
  --ak-shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
  --ak-shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
  
  /* Transiciones */
  --ak-transition-fast: 150ms cubic-bezier(0.4, 0, 0.2, 1);
  --ak-transition-normal: 300ms cubic-bezier(0.4, 0, 0.2, 1);
  
  /* Escalado de fuente */
  --ak-font-scale: 1;
}
```

### Especificidad CSS

```css
/* Mínima especificidad (0,1,0) */
.ak-button { /* ... */ }

/* Necesaria para temas (0,1,1) */
html[data-ak-contrast="high"] .ak-button { /* ... */ }

/* Evitar 0,2,0 o superior */
/* Especificidad normalizada para mantenibilidad */
```

### Optimizaciones

```css
/* Contención - Mejora performance */
.ak-panel-header {
  contain: layout style paint;
}

.ak-controls {
  contain: content;
}

/* Hardware Acceleration */
.ak-button {
  will-change: transform; /* Solo cuando es necesario */
  transform: translate3d(0, 0, 0);
}

/* CSS Variables en lugar de duplicación */
/* ✅ Una sola definición */
--ak-primary: #2563eb;

/* Modo oscuro automático */
@media (prefers-color-scheme: dark) {
  :root {
    --ak-text: #f9fafb;
  }
}
```

---

## ⌨️ Navegación por Teclado

### Atajos Implementados

```
Alt + A        → Alternar panel
Escape         → Cerrar panel
Tab            → Navegar controles (forward)
Shift + Tab    → Navegar controles (backward)
Enter          → Activar botón enfocado
Space          → Activar botón enfocado
```

### Orden de Tab (Tabborder)

```
1. Botón flotante (ak-button)
2. Botón cerrar (ak-close-button)
3. Primer control (ak-control-button)
4. Otros controles (orden DOM)
5. Último control
6. Vuelve a botón flotante (ciclo)
```

---

## 🔒 Seguridad

### Prevención de XSS

```javascript
// ✅ Seguro
element.textContent = userInput;
element.dataset.action = userInput;
element.setAttribute('aria-label', userInput);

// ❌ Inseguro
element.innerHTML = userInput;
element.innerText = userInput; // Puede ejecutar scripts
```

### Validación de localStorage

```javascript
// ✅ Validación completa
const prefs = JSON.parse(localStorage.getItem('ak-preferences'));
if (prefs && typeof prefs === 'object') {
  // Safe to use
  Object.assign(this.state, prefs);
}

// ❌ Sin validación
Object.assign(this.state, JSON.parse(localStorage.getItem('ak-preferences')));
```

### Encapsulación (IIFE)

```javascript
(function(window) {
  'use strict';
  
  // Scope privado
  class AccessibilityKit { /* ... */ }
  
  // Exportar globalmente
  window.AccessibilityKit = AccessibilityKit;
  
})(window);
```

---

## 📊 Performance Optimizations

### JavaScript

```javascript
// Delegación de eventos (1 listener vs N)
panel.addEventListener('click', handleEvent);

// Caching de referencias DOM
const button = this.elements.button;
const panel = this.elements.panel;

// Évitar consultas innecesarias
this.focusableElements = Array.from(
  document.querySelectorAll(/* selector */)
); // Se ejecuta en init, no cada vez

// Debouncing (no implementado pues no es necesario)
// Throttling (no necesario)

// Lazy initialization
this.setupMutationObserver(); // Solo se ejecuta una vez

// Memory leak prevention
this.mutationObserver.disconnect();
removeEventListener(); // Limpiar listeners
```

### CSS

```css
/* Selectores optimizados */
.ak-button { /* más rápido que div.ak-button */ }

/* Evitar selectores complejos */
✅ .ak-panel .ak-control-button { }
❌ div.ak-panel > div.ak-section > div.ak-controls > button.ak-control-button { }

/* Usar CSS Variables en lugar de precompiling */
✅ --ak-primary: var(--ak-primary);
❌ color: #2563eb; color: #1e40af; color: #3b82f6; /* repetición */

/* Hardware acceleration */
transform: translate3d(0, 0, 0);
opacity: 0.8;
/* Evitar: width, height, left, top (causan reflows) */
```

---

## 🧪 Testing Strategy

### Unit Testing

```javascript
// Estado inicial
expect(kit.state.textScale).toBe(100);
expect(kit.state.contrast).toBe('normal');

// Acciones
kit.adjustFontSize(10);
expect(kit.state.textScale).toBe(110);

// Persistencia
kit.savePreferences();
expect(localStorage.getItem('ak-preferences')).toBeDefined();
```

### Integration Testing

```javascript
// Flujo completo
kit.init();
kit.openPanel();
kit.setContrast('high');
kit.savePreferences();
kit.resetAll();
```

### Accessibility Testing

```javascript
// NVDA, JAWS, VoiceOver
// - Botón accesible
// - Panel modal
// - ARIA attributes correctos
// - Navegación por teclado
// - Orden de tab
```

### Performance Testing

```javascript
// Lighthouse
// LCP: < 1.5s
// INP: < 100ms
// CLS: 0.00

// Core Web Vitals
// Memory: < 2MB
// FID: < 100ms
```

---

## 🚀 Deployment

### Build Process

```bash
# 1. Minificar JavaScript
uglifyjs accessibility-kit.js -o accessibility-kit.min.js

# 2. Minificar CSS (opcional)
postcss accessibility-kit.css --output accessibility-kit.min.css

# 3. Gzip comprimir
gzip accessibility-kit.min.js
gzip accessibility-kit.min.css

# Resultados
# JS: 28 KB → 9.1 KB (gzip)
# CSS: 12 KB → 4.2 KB (gzip)
# Total: 13.3 KB
```

### Versioning

```
v1.0.0
└─ Major.Minor.Patch
   ├─ Major: Breaking changes
   ├─ Minor: New features (backward compatible)
   └─ Patch: Bug fixes
```

---

## 📈 Métricas y Monitoring

### Métricas de Uso

```javascript
// Rastrear inicialización
gtag('event', 'ak_initialized', {
  position: 'bottom-right',
  language: 'es'
});

// Rastrear panel abierto
document.addEventListener('ak-panel-open', () => {
  gtag('event', 'ak_panel_opened');
});

// Rastrear feature usado
gtag('event', 'ak_feature_used', {
  feature: 'contrast_high'
});
```

---

## 🔄 Ciclo de Vida

```
┌──────────────────────────────────────────┐
│ Accessibility Kit Lifecycle              │
├──────────────────────────────────────────┤
│                                          │
│ 1. INIT                                  │
│    └─ Constructor                        │
│    └─ init()                             │
│    └─ DOM creation                       │
│    └─ Event setup                        │
│                                          │
│ 2. READY                                 │
│    └─ Panel disponible                   │
│    └─ Preferencias cargadas              │
│    └─ Listeners activos                  │
│                                          │
│ 3. INTERACTION                           │
│    └─ Usuario interactúa                 │
│    └─ Estado actualizado                 │
│    └─ DOM modificado                     │
│    └─ Preferencias guardadas             │
│                                          │
│ 4. DESTROY (Opcional)                    │
│    └─ Limpiar DOM                        │
│    └─ Remover listeners                  │
│    └─ Cleanup memory                     │
│                                          │
└──────────────────────────────────────────┘
```

---

## 📚 Recursos Relacionados

- [WCAG 2.2](https://www.w3.org/WAI/WCAG22/quickref/)
- [WAI-ARIA](https://www.w3.org/WAI/ARIA/apg/)
- [Web APIs](https://developer.mozilla.org/en-US/docs/Web/API)
- [CSS Containment](https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Containment)
- [localStorage](https://developer.mozilla.org/en-US/docs/Web/API/Window/localStorage)

---

**Documento Generado:** 2024
**Versión:** 1.0.0
**Estado:** ✅ Production Ready

*Especificaciones técnicas del Accessibility Kit - Kit Universal de Accesibilidad Web*
