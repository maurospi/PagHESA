# 🚀 Guía Rápida de Integración

## Para el sitio "Hablando EnSeñas"

Esta guía te muestra cómo integrar el Accessibility Kit en tu sitio actual sin modificar nada del diseño o funcionalidad existente.

---

## Paso 1: Copiar Archivos

Copia la carpeta `accessibility-kit/` a la raíz de tu proyecto:

```
PagHESA/
├── accessibility-kit/
│   ├── accessibility-kit.js
│   ├── accessibility-kit.min.js
│   ├── accessibility-kit.css
│   ├── demo/
│   └── README.md
├── index.html
├── css/
├── js/
└── ...
```

---

## Paso 2: Actualizar index.html

### Opción A: Integración Recomendada (Una línea en cada sección)

**En la sección `<head>`, añade antes del cierre `</head>`:**

```html
<link rel="stylesheet" href="accessibility-kit/accessibility-kit.css">
```

**Antes del cierre `</body>`, añade:**

```html
<script src="accessibility-kit/accessibility-kit.js"></script>
<script>
  AccessibilityKit.init({
    position: 'bottom-right',
    language: 'es',
    savePreferences: true
  });
</script>
```

### Ejemplo Completo (Ubicación exacta)

```html
<!DOCTYPE html>
<html lang="es-CO">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="...">
  <meta name="author" content="Hablando EnSeñas">
  <link rel="icon" href="images/Logo/manoM.png">
  <title>Hablando EnSeñas</title>
  
  <!--Bootstrap-->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  <!--Stylesheets-->
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <!-- ... otros CSS ... -->
  
  <!-- 👇 AÑADE ESTO 👇 -->
  <link rel="stylesheet" href="accessibility-kit/accessibility-kit.css">
  <!-- 👆 AQUÍ 👆 -->
</head>

<body data-spy="scroll" data-target=".navbar-default" data-offset="100">
  <!-- Tu contenido aquí -->
  
  <!-- ... -->
  
  <!-- Scripts al final -->
  <script src="js/jquery.js"></script>
  <!-- ... otros scripts ... -->
  
  <!-- 👇 AÑADE ESTO ANTES DEL CIERRE </body> 👇 -->
  <script src="accessibility-kit/accessibility-kit.js"></script>
  <script>
    AccessibilityKit.init({
      position: 'bottom-right',
      language: 'es',
      savePreferences: true
    });
  </script>
  <!-- 👆 AQUÍ 👆 -->
</body>
</html>
```

---

## Paso 3: Verificar Integración

### En el navegador:

1. Abre tu sitio
2. Busca el botón flotante en la esquina inferior derecha
3. Haz clic para abrir el panel
4. Las funcionalidades deben ser accesibles

### Atajo de teclado:
- **Alt + A** abre/cierra el panel

---

## Opciones de Configuración

### Cambiar Posición del Botón

```javascript
AccessibilityKit.init({
  position: 'bottom-left'  // 'bottom-right' | 'bottom-left' | 'top-right' | 'top-left'
});
```

### Cambiar Idioma

```javascript
AccessibilityKit.init({
  language: 'en'  // 'es' | 'en'
});
```

### Desactivar Persistencia

```javascript
AccessibilityKit.init({
  savePreferences: false  // No guardar preferencias en localStorage
});
```

### Configuración Completa

```javascript
AccessibilityKit.init({
  position: 'bottom-right',
  language: 'es',
  primaryColor: 'auto',        // auto | color hex
  theme: 'auto',                // auto | light | dark
  savePreferences: true
});
```

---

## Verificar Lighthouse (Recomendado)

Después de integrar, verifica que los scores se mantengan:

1. Abre DevTools (F12)
2. Ve a Lighthouse
3. Genera un reporte
4. Verifica que sigues teniendo Lighthouse 100/100

El kit está altamente optimizado para NO afectar performance.

---

## Solucionar Problemas

### El botón no aparece

```javascript
// Verificar si está inicializado
console.log(window.AccessibilityKitInstance);

// Si no existe, hay error en la carga
// Verifica que:
// 1. Los archivos existan en la ruta correcta
// 2. No hay errores en la consola del navegador
// 3. JavaScript esté habilitado
```

### El CSS no se aplica

```html
<!-- Asegúrate de que el CSS esté ANTES de otros scripts -->
<link rel="stylesheet" href="accessibility-kit/accessibility-kit.css">
```

### Conflictos con Bootstrap

El kit está diseñado para NO conflictuar con Bootstrap 3. Si hay conflictos:

```css
/* Aumenta especificidad si es necesario */
html #accessibility-kit-button {
  z-index: 10000;
}
```

---

## Archivos Necesarios

Mínimo necesario para producción:

```
accessibility-kit/
├── accessibility-kit.css          (necesario)
├── accessibility-kit.min.js       (o .js)
└── demo/
    └── index.html                 (opcional - para demo)
```

---

## Uso Avanzado

### Abrir/Cerrar Panel Programáticamente

```javascript
const kit = AccessibilityKit.init();

// Abrir panel
kit.openPanel();

// Cerrar panel
kit.closePanel();

// Alternar
kit.togglePanel();

// Restablecer todo
kit.resetAll();
```

### Aplicar Configuraciones Automáticamente

```javascript
const kit = AccessibilityKit.init();

// Aplicar alto contraste automáticamente
kit.setContrast('high');

// Aumentar tamaño de texto
kit.adjustFontSize(20);

// Activar modo dislexia
kit.toggleDyslexiaFont();
```

---

## Integración con Analytics (Opcional)

Para rastrear uso de accesibilidad:

```javascript
AccessibilityKit.init({
  position: 'bottom-right',
  language: 'es'
});

// Rastrear cuando se abre el panel
const kit = window.AccessibilityKitInstance;
document.addEventListener('ak-panel-open', () => {
  // Enviar a Google Analytics, Mixpanel, etc.
  if (typeof gtag !== 'undefined') {
    gtag('event', 'accessibility_panel_opened');
  }
});
```

---

## Mejores Prácticas

✅ **HACE:**
- Integra el CSS en `<head>`
- Integra el JS antes de `</body>`
- Usa la ruta correcta relativa
- Verifica la consola del navegador para errores
- Prueba en diferentes dispositivos

❌ **NO HAGAS:**
- Modificar los archivos del kit
- Cambiar el nombre de las carpetas
- Incluir dos veces el mismo archivo
- Usar versiones antiguas

---

## Próximos Pasos

1. ✅ Integrar en index.html
2. ✅ Probar en navegador
3. ✅ Verificar Lighthouse
4. ✅ Probar en móvil
5. ✅ Verificar con lectores de pantalla
6. ✅ Publicar en producción

---

## Recursos

- 📖 [README Completo](./README.md)
- 🎨 [Demo Interactiva](./demo/index.html)
- ♿ [WCAG 2.2 AAA](https://www.w3.org/WAI/WCAG22/quickref/)
- 🎯 [WAI-ARIA](https://www.w3.org/WAI/ARIA/apg/)

---

## Soporte

Si tienes problemas:

1. Revisa la [consola del navegador](chrome://inspect) para errores
2. Lee la sección Troubleshooting del [README](./README.md)
3. Verifica que los archivos existan en las rutas correctas
4. Intenta con un navegador diferente

---

**¡Listo! Tu sitio ahora tiene accesibilidad de nivel empresarial.** 🎉

*El kit se integrará perfectamente sin modificar nada de tu diseño existente.*
